package com.example.honestapplication;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


public class MyListViewAdaptor extends ArrayAdapter<String> {
    private final Activity context;
    private final String[] imageNames;
    private final Integer[] proImages;

    public MyListViewAdaptor(Activity context, String[] imageNames, Integer[] ProImages) {
        super(context, R.layout.activity_list_view, imageNames);
        this.context = context;
        this.imageNames = MyDevProfile.imageNames;
        this.proImages = MyDevProfile.proImages;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = context.getLayoutInflater();
        View rowView = layoutInflater.inflate(R.layout.activity_list_view, null, true);
        TextView textTitle = rowView.findViewById(R.id.textView7);
        ImageView imageView = rowView.findViewById(R.id.imageView2);
        textTitle.setText(imageNames[position]);
        imageView.setImageResource(proImages[position]);
        return rowView;
    }
}