package com.example.honestapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class AboutMe extends AppCompatActivity {
    TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_me);

        ImageButton imageButton = findViewById(R.id.imageButton2);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AboutMe.this, Menu.class);
                startActivity(intent);

            }
        });

        textView = findViewById(R.id.textViewAboutMe);
        textView.setText("Hi I am Honest Mpungu. " +
                "Studying  Information Technology at CPUT." +
                " Majoring in Applications Development . " );

    }
}
